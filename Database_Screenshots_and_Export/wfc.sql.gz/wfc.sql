-- phpMyAdmin SQL Dump
-- version 4.4.15.7
-- http://www.phpmyadmin.net
--
-- Хост: 127.0.0.1:3306
-- Время создания: Май 13 2018 г., 19:57
-- Версия сервера: 5.6.31
-- Версия PHP: 5.6.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `wfc`
--

-- --------------------------------------------------------

--
-- Структура таблицы `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(10) unsigned NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `categories`
--

INSERT INTO `categories` (`id`, `title`, `created_at`, `updated_at`) VALUES
(1, 'Spain', '2018-05-13 07:40:08', '2018-05-13 07:40:08'),
(2, 'Italy', '2018-05-13 07:40:26', '2018-05-13 07:40:26'),
(3, 'Germany', '2018-05-13 07:40:36', '2018-05-13 07:40:36'),
(4, 'France', '2018-05-13 07:40:45', '2018-05-13 07:40:45'),
(5, 'Russia', '2018-05-13 07:41:01', '2018-05-13 07:41:01'),
(6, 'England', '2018-05-13 07:41:28', '2018-05-13 07:41:28'),
(7, 'Japan', '2018-05-13 07:41:51', '2018-05-13 07:41:51'),
(8, 'Korea', '2018-05-13 07:42:02', '2018-05-13 07:42:02'),
(9, 'Uzbekistan and CIS', '2018-05-13 07:42:17', '2018-05-13 07:42:17'),
(10, 'Brazil', '2018-05-13 07:42:43', '2018-05-13 07:42:43'),
(11, 'Chile', '2018-05-13 07:42:48', '2018-05-13 07:42:48'),
(12, 'Columbia', '2018-05-13 07:42:56', '2018-05-13 07:42:56'),
(13, 'USA', '2018-05-13 07:43:00', '2018-05-13 07:43:00'),
(14, 'World cup - 2018', '2018-05-13 07:49:18', '2018-05-13 07:49:18'),
(15, 'UEFA', '2018-05-13 07:49:54', '2018-05-13 07:49:54');

-- --------------------------------------------------------

--
-- Структура таблицы `matches`
--

CREATE TABLE IF NOT EXISTS `matches` (
  `id` int(10) unsigned NOT NULL,
  `first_team` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `first_score` int(11) NOT NULL,
  `second_score` int(11) NOT NULL,
  `second_team` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `match_date` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `matches`
--

INSERT INTO `matches` (`id`, `first_team`, `first_score`, `second_score`, `second_team`, `match_date`, `created_at`, `updated_at`) VALUES
(1, 'Liverpool', 2, 1, 'Real Madrid', '2018-05-26', '2018-05-12 05:59:32', '2018-05-12 05:59:32'),
(2, 'Chelsea', 0, 1, 'Bayern Munchen', '2018-01-05', '2018-05-12 06:07:23', '2018-05-12 06:07:23');

-- --------------------------------------------------------

--
-- Структура таблицы `migrations`
--

CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) unsigned NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2018_05_01_094438_create_posts_table', 1),
(4, '2018_05_11_181616_create_categories_table', 2),
(5, '2018_05_12_100919_create_matches_table', 3),
(6, '2018_05_12_121313_create_roles_table', 4),
(7, '2018_05_12_121641_create_role_table', 5);

-- --------------------------------------------------------

--
-- Структура таблицы `password_resets`
--

CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `posts`
--

CREATE TABLE IF NOT EXISTS `posts` (
  `id` int(10) unsigned NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` int(11) DEFAULT '0',
  `category_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `posts`
--

INSERT INTO `posts` (`id`, `title`, `description`, `content`, `image`, `user_id`, `category_id`, `created_at`, `updated_at`) VALUES
(1, 'dfgdfg', 'sdfsd', '<p>sdfsdf</p>', 'noimage.jpg', 1, 1, '2018-05-12 05:02:07', '2018-05-12 05:02:07'),
(2, 'xvcb', 'cvbcvb', '<p>sdfds</p>', 'noimage.jpg', 1, 4, '2018-05-12 05:02:16', '2018-05-12 05:02:16'),
(3, 'retret', 'ertret', '<p>fgddgdfg</p>', 'noimage.jpg', 1, 1, '2012-05-20 13:00:00', '2012-05-20 13:00:00'),
(4, 'Post 1', 'dfgfdg', '<p>dsfsfs</p>', 'noimage.jpg', 1, 1, '2018-05-12 05:14:54', '2018-05-12 05:14:54'),
(5, 'dfgfdg', 'dfgdfg', '<p>dfgfdg&nbsp; &nbsp;dfgdfg&nbsp; dfg</p>', 'noimage.jpg', 1, 1, '2018-05-13 10:24:56', '2018-05-13 10:24:56');

-- --------------------------------------------------------

--
-- Структура таблицы `roles`
--

CREATE TABLE IF NOT EXISTS `roles` (
  `id` int(10) unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `roles`
--

INSERT INTO `roles` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'admin', NULL, NULL),
(2, 'moderator', NULL, NULL),
(3, 'user', NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role_id` int(11) NOT NULL DEFAULT '3',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `role_id`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'dilmurod', 'd@inha.uz', '$2y$10$dShpzXpFhbjToe8qK9GUjOkO6GU2b6gfhDpGWvD7VwdpFGfK0V1hK', 1, 'ECwQiswSwye6E9Vt9ranWl32gphdVr0wfIX5YVvLOlcesLxUG1Sf7KzLq8rH', '2018-05-09 14:10:13', '2018-05-09 14:10:13'),
(2, 'Test', 'test@inha.uz', '$2y$10$Xhy57DDg//RXmUSdITnlI.u8crWYS.NkWzvPqvaJvOcB5dAGQvPKS', 2, 'HMcllDT9es3wps2RY4q2BpgY0WcZv04afyVX9ld6lOOXja9WHwJWozKmccYi', '2018-05-12 08:41:22', '2018-05-12 08:43:28');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `matches`
--
ALTER TABLE `matches`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Индексы таблицы `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT для таблицы `matches`
--
ALTER TABLE `matches`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT для таблицы `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT для таблицы `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT для таблицы `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
